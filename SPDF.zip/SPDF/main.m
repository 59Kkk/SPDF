clc;
clear all;
for j=4
    index = j;
    path1 = ['./image/',num2str(index),'.png'];
    im = imread(path1);
    %%  pretreatment
    [input1,input2] = preprocess(im);
    %%  fusion
    [F1,F2,F3,F4] = getImgBlock_to_fusion(input1,input2);
    %% reconsFromBlock---result
    [h,w,n] = size(im);
    img_temp = zeros(h,w,n);
    F = reconsFromBlock(img_temp,F1, F2, F3, F4);
    figure

    imshow(F)
end